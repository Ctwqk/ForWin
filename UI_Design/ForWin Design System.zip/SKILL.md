---
name: forwin-design
description: Use this skill to generate well-branded interfaces and assets for ForWin, the AI-assisted Chinese long-form web-novel generation and publishing platform, either for production code or throwaway prototypes, mocks, slides, and pitches. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping the creator workspace and the World Studio (canon/graph) surfaces.
user-invocable: true
---

# ForWin Design Skill

Read the README.md file within this skill, and explore the other available files:

- `colors_and_type.css` — design tokens (colors, type, spacing, radii, shadows, motion) and semantic helper classes.
- `assets/` — favicon, brand mark, paper texture SVG.
- `preview/` — small per-token specimen cards used to populate the design system tab.
- `ui_kits/creator-workspace/` — hi-fi mock of the creator home (Books, Tasks, Config, Genesis).
- `ui_kits/world-studio/` — hi-fi mock of the World Archive (Pages, Graph, Proposals, Personality).
- `SKILL.md` — this descriptor.

## When making visual artifacts (slides, mocks, throwaway prototypes)

1. Import `colors_and_type.css` to inherit every token and the semantic type classes (`.fw-h1`, `.fw-eyebrow`, …). Never invent new colors or fonts — the brand palette is intentionally restrained.
2. Put the parchment paper background on `body` (see `preview/_card.css` for the canonical recipe — a stacked radial + linear gradient + a 104px column-rule pattern overlay).
3. Use serif (`var(--font-display)` → Source Serif 4) for page titles and modal titles; UI sans (`var(--font-ui)` → Plus Jakarta Sans) for everything else; mono (`var(--font-mono)` → JetBrains Mono) for JSON / hashes / digests.
4. Cards are 22–28px radius, 1px warm hairline, warm shadow, white-to-cream vertical gradient fill. Buttons are pills. See `ui_kits/creator-workspace/styles.css` for the canonical `.card` and `.btn` rules.
5. Copy icons from Lucide via CDN (`https://unpkg.com/lucide@latest`). Never hand-roll SVGs.
6. Tone: Chinese-led, technical-but-warm. Sentences end with `。`. No emoji. No exclamation marks. Mix English technical nouns (`Proposal`, `Operation Mode`, `Snapshot`) inline. See README's "Content fundamentals" section for examples to mimic.
7. Copy `assets/brand-mark.svg` into the artifact when an in-context lockup is needed.

## When working in production code

You can copy `colors_and_type.css` directly into a project, then read this skill's READMEs to become an expert on ForWin's content and visual rules. The existing ForWin codebase lives at <https://github.com/Ctwqk/ForWin> (default branch `master`), under `frontend/world-studio/src/` and `forwin/ui_assets/`. The design tokens in `colors_and_type.css` are a refined superset of what's already in the codebase — every value either matches the source exactly or is an explicit upgrade.

## When the user invokes this skill with no other guidance

Ask:
1. What surface? (`creator workspace`, `world studio`, a brand-new screen, a slide deck)
2. What fidelity? (`exploration`, `hi-fi mock`, `production HTML/CSS`)
3. Any specific brand asset substitutions to flag? (font files, real book covers, illustrator-supplied artwork)

Then act as the in-house ForWin designer and produce HTML artifacts or production code, choosing the appropriate output by what the user actually needs to do with the result.
