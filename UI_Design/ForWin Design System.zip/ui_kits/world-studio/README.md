# World Studio — ForWin UI Kit

World Studio is the canon-and-graph tool at `/world-studio`. The original is a Vite React app in `frontend/world-studio/src/` and currently uses a generic neutral palette that drifts away from the warm creator workspace.

**This kit pulls World Studio back into the parchment brand** while preserving every tab and panel from the source: 页面 (Pages), 图谱 (Graph), 搜索 (Search), Proposal, 人物性格 (Personality).

## What's covered

- **Shell** — primary nav lockup matched to the creator workspace; reuses the same masthead + status-bar layout.
- **Workspace** — left sidebar (search, type filter, page list) + right detail panel.
- **Tabs** — Pages / Graph / Search / Proposals / Personality, parchment-styled.
- **Detail surfaces** — Page metadata, snapshot timeline, frontmatter pre, markdown projection, page editor with proposal triggers.
- **Side surfaces** — proposal list with accept/reject, graph node grid + edge list, personality coverage panel.

## What's intentionally trimmed

- The full personality editor (skill catalog, assignment report, active-context preview) is shown as one component with mock data; the original is much deeper.
- Real `/api/projects/*` calls — the kit ships seeded data so the demo runs offline.

Open `index.html` to see the kit running.
