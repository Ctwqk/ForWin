/* global React, Badge, Button, Icon */
const { useState: useStateBook } = React;

function BookCover({ title, glyph }) {
  return (
    <div className="book-cover" aria-label={title}>
      <span style={{ fontSize: 16, lineHeight: 1.25 }}>{glyph || title.slice(0, 4)}</span>
    </div>
  );
}

function BookCard({ book, onOpenGenesis }) {
  const pct = Math.round((book.chaptersDone / book.chaptersTotal) * 100);
  return (
    <article className="list-item">
      <div className="book-row">
        <BookCover title={book.title} glyph={book.glyph} />
        <div>
          <div className="task-id">{book.id} · {book.status}</div>
          <h3 className="book-title">{book.title}</h3>
          <p className="book-meta">{book.genre} · {book.chaptersTotal} 章 · {book.audience}</p>
          <div className="book-progress" style={{ marginTop: 10 }}>
            <div className="muted" style={{ display: "flex", justifyContent: "space-between" }}>
              <span>已生成 {book.chaptersDone} / 已上传 {book.chaptersUploaded}</span>
              <span>{pct}%</span>
            </div>
            <div className="progress-bar"><span className="fill" style={{ width: pct + "%" }}></span></div>
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 12, flexWrap: "wrap" }}>
            {book.badges.map((b, i) => (
              <Badge key={i} tone={b.tone}>{b.label}</Badge>
            ))}
          </div>
        </div>
        <div style={{ display: "grid", gap: 8, justifyItems: "end" }}>
          <Button tone="primary" icon="sparkles" onClick={() => onOpenGenesis(book)}>打开 Genesis</Button>
          <Button tone="secondary" icon="play">继续写作</Button>
          <Button tone="ghost" icon="upload">推送上传</Button>
        </div>
      </div>
    </article>
  );
}

function BookPanel({ books, onNewBook, onOpenGenesis }) {
  return (
    <section>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14, gap: 14 }}>
        <div className="section-head" style={{ margin: 0 }}>
          <div>
            <h2>书本管理</h2>
            <p>这里看每本书的章节规划、已生成章节和已上传章节。建书和后续生成从这里发起。</p>
          </div>
        </div>
        <div className="action-row">
          <Button tone="secondary" icon="refresh-cw">刷新</Button>
          <Button tone="ghost">全选</Button>
          <Button tone="danger" icon="trash-2" disabled>批量删除</Button>
          <Button tone="primary" icon="plus" onClick={onNewBook}>新建书本</Button>
        </div>
      </div>
      <div className="list">
        {books.map((b) => <BookCard key={b.id} book={b} onOpenGenesis={onOpenGenesis} />)}
      </div>
    </section>
  );
}

Object.assign(window, { BookCard, BookPanel });
