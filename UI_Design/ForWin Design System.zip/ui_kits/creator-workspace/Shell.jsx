/* global React */
const { useState } = React;

function Icon({ name, size = 16, color }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = "";
      const el = document.createElement("i");
      el.setAttribute("data-lucide", name);
      el.style.width = size + "px";
      el.style.height = size + "px";
      if (color) el.style.color = color;
      ref.current.appendChild(el);
      window.lucide.createIcons({ nameAttr: "data-lucide" });
    }
  }, [name, size, color]);
  return <span ref={ref} style={{ display: "inline-flex", lineHeight: 0 }} />;
}

function Badge({ tone = "neutral", children }) {
  return <span className={`badge ${tone === "neutral" ? "" : tone}`}>{children}</span>;
}

function Button({ tone = "ghost", icon, children, onClick, disabled }) {
  const cls = `btn btn-${tone}` + (disabled ? " disabled" : "");
  return (
    <button className={cls} onClick={onClick} disabled={disabled}>
      {icon ? <Icon name={icon} size={16} /> : null}
      {children}
    </button>
  );
}

function PrimaryNav({ tab, setTab }) {
  const items = [
    { key: "book", label: "书本" },
    { key: "task", label: "任务" },
    { key: "world", label: "世界档案", href: "../world-studio/index.html" },
    { key: "publish", label: "发布" },
    { key: "config", label: "配置" }
  ];
  return (
    <nav className="nav-tabs" aria-label="ForWin primary navigation">
      {items.map((it) =>
        it.href ? (
          <a key={it.key} className="nav-tab" href={it.href}>{it.label}</a>
        ) : (
          <button
            key={it.key}
            className={`nav-tab ${tab === it.key ? "active" : ""}`}
            type="button"
            onClick={() => setTab(it.key)}
          >
            {it.label}
          </button>
        )
      )}
    </nav>
  );
}

function StatusBar({ tasksRunning, apiKeyOk, codexBridgeOk, extensionOk }) {
  return (
    <div className="status-bar">
      <div>
        <strong>系统状态</strong>
        <div className="meta">
          {tasksRunning} 项任务运行中 · 最近同步 2 分钟前
        </div>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <Badge tone={apiKeyOk ? "ok" : "warn"}>API Key：{apiKeyOk ? "已保存" : "未保存"}</Badge>
        <Badge tone={codexBridgeOk ? "ok" : "warn"}>Codex：{codexBridgeOk ? "在线" : "未检查"}</Badge>
        <Badge tone={extensionOk ? "ok" : "warn"}>扩展回写：{extensionOk ? "已配置" : "未配置"}</Badge>
      </div>
    </div>
  );
}

function Masthead() {
  return (
    <section className="masthead">
      <div>
        <div className="brand-mark">
          <img src="../../assets/brand-mark.svg" alt="" style={{ height: 22, marginRight: -4 }} />
          ForWin Workspace
        </div>
        <h1>配置归配置，<br />任务归任务。</h1>
        <p>
          首页拆成书本、任务、配置三个视角。书本先进入 Genesis 创世，再启动写作；任务中心继续承接生成与上传执行流，配置页只保留模型与平台登录。
        </p>
      </div>
    </section>
  );
}

Object.assign(window, { Icon, Badge, Button, PrimaryNav, StatusBar, Masthead });
