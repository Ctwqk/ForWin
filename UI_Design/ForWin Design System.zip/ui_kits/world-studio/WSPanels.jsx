/* global React, Badge, Button, Icon */

function WSPageDetail({ page }) {
  if (!page) {
    return (
      <div className="empty" style={{ minHeight: 360, display: "grid", placeContent: "center" }}>
        <strong>还没有世界档案页面</strong>
        <div>锁定 Genesis 或导出 Obsidian 时会自动 bootstrap 第 0 章世界模型。</div>
      </div>
    );
  }
  return (
    <>
      <div className="panel-head">
        <div>
          <div className="eyebrow">{page.page_type}</div>
          <h2>{page.title}</h2>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <Badge>{page.status}</Badge>
          <Badge>rev {page.revision}</Badge>
          <Badge>ch {page.as_of_chapter}</Badge>
        </div>
      </div>

      <div className="detail-grid">
        <section className="summary-panel">
          <h3>Metadata</h3>
          <dl className="kv">
            <dt>Page Key</dt><dd><code>{page.page_key}</code></dd>
            <dt>Vault Path</dt><dd><code>{page.vault_path}</code></dd>
            <dt>Source Digest</dt><dd><code>{page.source_digest}</code></dd>
            <dt>Projection</dt><dd>{page.projection_kind} · {page.projection_version}</dd>
            <dt>Role Scope</dt><dd>{page.role_scope}</dd>
            <dt>Visibility</dt><dd>{page.visibility_scope}</dd>
          </dl>
        </section>
        <section className="summary-panel">
          <h3>Snapshot Timeline</h3>
          <ol className="timeline">
            {page.snapshots.map((s) => (
              <li key={s.version}>
                <strong>ch {s.as_of_chapter}</strong>
                <span>v{s.version}</span>
                <span style={{ fontFamily: "var(--font-mono)" }}>{s.digest}</span>
              </li>
            ))}
          </ol>
        </section>
      </div>

      <section className="markdown-panel">
        <h3>Frontmatter</h3>
        <pre className="code-block">{JSON.stringify(page.frontmatter, null, 2)}</pre>
      </section>

      <section className="markdown-panel">
        <h3>Page Editor</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
          {[
            { field: "Manual Notes", placeholder: "项目级人工备注。提交后生成 NoteOnly proposal。" },
            { field: "Human Questions", placeholder: "你想让 reviewer / 后续 AI 回答的问题。" },
            { field: "Proposed Correction", placeholder: "改写 canon 的具体补丁。需要审核才进入正式 canon。" }
          ].map((f) => (
            <div key={f.field} className="field-stack">
              <label>{f.field}</label>
              <textarea className="field" placeholder={f.placeholder} />
              <Button tone="secondary" icon="git-branch">生成 proposal</Button>
            </div>
          ))}
        </div>
      </section>

      <section className="markdown-panel">
        <h3>Markdown Projection</h3>
        <pre className="code-block">{page.markdown}</pre>
      </section>
    </>
  );
}

function WSGraphView({ page }) {
  const nodes = [
    { id: "char:protagonist", title: "见习医师 · 沈柏舟", type: "character", current: page?.page_key === "character:protagonist" },
    { id: "char:antagonist", title: "议会议长 · 苏伯禹", type: "character" },
    { id: "loc:ash-city", title: "灰烬城", type: "location" },
    { id: "faction:council", title: "议会", type: "faction" },
    { id: "artifact:codex", title: "蜡封药典", type: "artifact" },
    { id: "event:plague", title: "黑霜瘟", type: "event" }
  ];
  const edges = [
    { src: "char:protagonist", dst: "loc:ash-city", family: "social", type: "lives_in", status: "active" },
    { src: "char:protagonist", dst: "char:antagonist", family: "control_conflict", type: "antagonist_of", status: "active" },
    { src: "char:antagonist", dst: "faction:council", family: "social", type: "leader_of", status: "active" },
    { src: "char:protagonist", dst: "artifact:codex", family: "knowledge_visibility", type: "knows_of", status: "suspected" },
    { src: "loc:ash-city", dst: "event:plague", family: "reader_experience", type: "scene_of", status: "active" }
  ];
  return (
    <>
      <div className="panel-head">
        <div>
          <div className="eyebrow">Object Graph</div>
          <h2>{page?.title ?? "灰烬城世界图"}</h2>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <Badge>1-hop</Badge>
          <Badge>{edges.length} edges</Badge>
        </div>
      </div>
      <div className="graph-node-grid">
        {nodes.map((n) => (
          <div key={n.id} className={`graph-node ${n.current ? "current" : ""}`}>
            <strong>{n.title}</strong>
            <span>{n.type}</span>
          </div>
        ))}
      </div>
      <h3 style={{ margin: "18px 0 10px", font: "700 18px/1.2 var(--font-display)" }}>Edges</h3>
      <div className="graph-edge-list">
        {edges.map((e, i) => (
          <article key={i} className="graph-edge">
            <strong>{e.src} → {e.dst}</strong>
            <span>{e.family} · {e.type} · {e.status}</span>
          </article>
        ))}
      </div>
    </>
  );
}

function WSProposals() {
  const proposals = [
    { id: "PR-21", target: "character:protagonist", proposal_type: "NoteOnlyProposal", reason: "Add observation about reluctance to use canon medicine.", source: "world_studio", status: "pending" },
    { id: "PR-22", target: "location:ash-city", proposal_type: "CanonCorrectionProposal", reason: "Frontmatter visibility_scope drift from Obsidian.", source: "obsidian_import", status: "pending" },
    { id: "PR-23", target: "character:antagonist", proposal_type: "PersonalityLoadoutProposal", reason: "Move from auto fallback to manual loadout.", source: "world_studio", status: "pending" }
  ];
  return (
    <>
      <div className="panel-head">
        <div>
          <div className="eyebrow">Governance</div>
          <h2>Proposals</h2>
        </div>
        <Badge tone="warn">{proposals.length} pending</Badge>
      </div>
      <div style={{ display: "grid", gap: 12 }}>
        {proposals.map((pr) => (
          <article key={pr.id} className="proposal-row">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
              <div>
                <strong>{pr.target}</strong>
                <div className="reason" style={{ fontFamily: "var(--font-mono)" }}>{pr.id} · {pr.source}</div>
              </div>
              <Badge>{pr.proposal_type}</Badge>
            </div>
            <div className="reason">{pr.reason}</div>
            <div className="actions">
              <Button tone="ghost" icon="x">拒绝</Button>
              <Button tone="primary" icon="check">接受</Button>
            </div>
          </article>
        ))}
      </div>
    </>
  );
}

function WSPersonality() {
  return (
    <>
      <div className="panel-head">
        <div>
          <div className="eyebrow">Character Personality</div>
          <h2>见习医师 · 沈柏舟</h2>
        </div>
        <Badge tone="ok">manual loadout</Badge>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(260px, 360px)", gap: 14 }}>
        <section className="summary-panel">
          <h3>Loadout</h3>
          <pre className="code-block">{`{
  "dominant": "compassion-driven-healer",
  "secondary": ["scholarly-skeptic", "quiet-defiant"],
  "social_mask": ["guild-junior"],
  "stress_modes": ["withdraw-into-notebook"],
  "overrides": {}
}`}</pre>
          <div className="action-row" style={{ marginTop: 12 }}>
            <Button tone="secondary" icon="git-branch">生成 proposal</Button>
            <Button tone="ghost" icon="rotate-cw">重新分配</Button>
            <Button tone="ghost" icon="eye">Active context preview</Button>
          </div>
        </section>
        <section className="summary-panel">
          <h3>Skill Catalog</h3>
          <div style={{ display: "grid", gap: 8 }}>
            {[
              ["compassion-driven-healer", "v0.4", "dominant trait"],
              ["scholarly-skeptic", "v0.3", "secondary trait"],
              ["quiet-defiant", "v0.2", "secondary trait"],
              ["guild-junior", "v0.5", "social mask"],
              ["withdraw-into-notebook", "v0.1", "stress mode"]
            ].map(([n, v, kind]) => (
              <div key={n} style={{ padding: 10, border: "1px solid rgba(204,177,147,.46)", borderRadius: 14, background: "rgba(255,255,255,.6)" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <strong style={{ font: "700 13px/1.2 var(--font-mono)" }}>{n}</strong>
                  <span className="muted" style={{ fontSize: 11 }}>{v}</span>
                </div>
                <div className="muted" style={{ marginTop: 2 }}>{kind}</div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}

Object.assign(window, { WSPageDetail, WSGraphView, WSProposals, WSPersonality });
