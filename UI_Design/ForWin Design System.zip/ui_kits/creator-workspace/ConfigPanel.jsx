/* global React, Badge, Button, Icon */

function ConfigPanel({ profiles, platforms }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.05fr) minmax(360px, 0.95fr)", gap: 18 }}>
      <div style={{ display: "grid", gap: 18 }}>
        <section className="card">
          <div className="section-head">
            <div>
              <h2 style={{ fontSize: 22 }}>Codex Bridge</h2>
              <p>Pro 订阅通过宿主机 bridge 接入；失败时按路由策略回退普通模型。</p>
            </div>
            <Button tone="secondary" icon="refresh-cw">刷新</Button>
          </div>
          <div style={{ display: "grid", gap: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 14px", border: "1px solid rgba(33,104,65,.24)", borderRadius: 18, background: "rgba(33,104,65,.08)" }}>
              <div>
                <div style={{ font: "800 14px/1.2 var(--font-ui)" }}>codex-bridge-01</div>
                <div className="muted">Pro · 已注册 · 上次心跳 8 秒前</div>
              </div>
              <Badge tone="ok">在线</Badge>
            </div>
          </div>
        </section>

        <section className="card">
          <div className="section-head">
            <div>
              <h2 style={{ fontSize: 22 }}>模型列表</h2>
              <p>每条模型只展示必要元信息；新增和编辑都走同一个设置弹窗。</p>
            </div>
            <div className="action-row">
              <Button tone="secondary" icon="refresh-cw">刷新</Button>
              <Button tone="primary" icon="plus">添加模型</Button>
            </div>
          </div>
          <div style={{ display: "grid", gap: 10 }}>
            {profiles.map((p) => (
              <div key={p.id} style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 12, padding: 14, border: "1px solid rgba(204,177,147,.46)", borderRadius: 20, background: "rgba(255,255,255,.62)", alignItems: "center" }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <strong style={{ font: "800 14px/1.2 var(--font-ui)" }}>{p.name}</strong>
                    {p.isDefault ? <Badge tone="ok">默认</Badge> : null}
                  </div>
                  <div className="muted" style={{ marginTop: 2 }}>{p.provider} · {p.model}</div>
                  <div className="muted" style={{ fontFamily: "var(--font-mono)", fontSize: 12, marginTop: 2 }}>{p.baseUrl}</div>
                </div>
                <div className="action-row">
                  <Button tone="ghost" icon="pencil">编辑</Button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="card">
          <div className="section-head">
            <div>
              <h2 style={{ fontSize: 22 }}>生成设置</h2>
              <p>这些是新建生成任务的默认值；任务弹窗里仍可按单次任务覆盖。</p>
            </div>
            <Button tone="primary" icon="save">保存</Button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 }}>
            <div>
              <label className="field-label">每章最少字数</label>
              <input className="field" type="number" defaultValue={2800} />
            </div>
            <div>
              <label className="field-label">每 N 章人工检查</label>
              <input className="field" type="number" defaultValue={8} />
            </div>
            <div style={{ gridColumn: "1 / -1" }}>
              <label className="field-label">Operation Mode</label>
              <select className="field">
                <option>blackbox</option>
                <option>copilot</option>
                <option>checkpoint</option>
              </select>
            </div>
          </div>
        </section>
      </div>

      <div style={{ display: "grid", gap: 18 }}>
        <section className="card">
          <div className="section-head">
            <div>
              <h2 style={{ fontSize: 22 }}>浏览器扩展</h2>
              <p>下载用户端浏览器扩展，或打开已经安装的扩展设置。扩展设置里填写当前 ForWin 后端地址和共享 API Key。</p>
            </div>
          </div>
          <div className="action-row">
            <Button tone="secondary" icon="settings">打开扩展设置</Button>
            <Button tone="secondary" icon="download">下载 Chrome 包</Button>
            <Button tone="secondary" icon="download">下载 Firefox 包</Button>
          </div>
          <p className="muted" style={{ marginTop: 12 }}>
            Chrome/Edge 下载后解压并加载 <code style={{ fontFamily: "var(--font-mono)", background: "rgba(31,91,84,.08)", padding: "2px 6px", borderRadius: 6 }}>browser_extension/forwin-publisher</code>。
          </p>
        </section>

        <section className="card">
          <div className="section-head">
            <div>
              <h2 style={{ fontSize: 22 }}>平台列表</h2>
              <p>这里直接看平台登录状态、扩展在线状态和当前执行端 Client ID。</p>
            </div>
            <Button tone="secondary" icon="refresh-cw">刷新</Button>
          </div>
          <div style={{ display: "grid", gap: 10 }}>
            {platforms.map((pl) => (
              <div key={pl.id} style={{ padding: 14, border: "1px solid rgba(204,177,147,.46)", borderRadius: 20, background: "rgba(255,255,255,.62)", display: "grid", gap: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                  <strong style={{ font: "800 14px/1.2 var(--font-ui)" }}>{pl.name}</strong>
                  <Badge tone={pl.loggedIn ? "ok" : "warn"}>{pl.loggedIn ? "已登录" : "未登录"}</Badge>
                </div>
                <div className="muted">扩展：{pl.extensionOnline ? "在线" : "离线"} · Client {pl.client}</div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

Object.assign(window, { ConfigPanel });
