/* global React, Badge, Button, Icon */

function TaskCard({ task, onOpen }) {
  const stages = task.stages || [];
  return (
    <article className="list-item">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 14 }}>
        <div>
          <div className="task-id">{task.id} · {task.kind === "generation" ? "生成任务" : "上传任务"}</div>
          <h3 style={{ margin: "4px 0 4px", font: "700 18px/1.2 var(--font-display)", letterSpacing: "-0.02em" }}>
            {task.title}
          </h3>
          <div className="muted">{task.summary}</div>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <Badge tone={task.toneOverall}>{task.statusLabel}</Badge>
          <Badge>{task.modelProfile}</Badge>
        </div>
      </div>
      {stages.length ? (
        <div className="macro-flow">
          {stages.map((s, i) => (
            <div key={i} className={`macro-node ${s.state}`}>
              <strong>{s.label}</strong>
              <span>{s.note}</span>
            </div>
          ))}
        </div>
      ) : null}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <div className="muted">{task.updatedAt}</div>
        <div className="action-row">
          <Button tone="ghost" icon="eye" onClick={() => onOpen(task)}>查看详情</Button>
          {task.kind === "generation" ? (
            <Button tone="secondary" icon="pause">暂停</Button>
          ) : (
            <Button tone="secondary" icon="external-link">前往平台</Button>
          )}
        </div>
      </div>
    </article>
  );
}

function TaskPanel({ tasks, onOpen, onNewTask }) {
  return (
    <section>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14, gap: 14 }}>
        <div className="section-head" style={{ margin: 0 }}>
          <div>
            <h2>统一任务中心</h2>
            <p>生成任务与上传任务按更新时间混排；右侧抽屉承接任务详情、章节查看和从章节直接派生上传任务。</p>
          </div>
        </div>
        <div className="action-row">
          <Button tone="secondary" icon="refresh-cw">刷新</Button>
          <Button tone="ghost">全选可删</Button>
          <Button tone="danger" icon="trash-2" disabled>批量删除</Button>
          <Button tone="primary" icon="plus" onClick={onNewTask}>新建任务</Button>
        </div>
      </div>
      <div className="list">
        {tasks.map((t) => <TaskCard key={t.id} task={t} onOpen={onOpen} />)}
      </div>
    </section>
  );
}

Object.assign(window, { TaskCard, TaskPanel });
