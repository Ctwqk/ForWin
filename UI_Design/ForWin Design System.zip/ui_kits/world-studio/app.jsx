/* global React, ReactDOM, PrimaryNav, WSMasthead, WSSidebar, WSPageDetail, WSGraphView, WSProposals, WSPersonality */

const SEED_PAGES = [
  {
    page_key: "character:protagonist",
    title: "见习医师 · 沈柏舟",
    page_type: "character",
    as_of_chapter: 12,
    revision: 14,
    status: "canon",
    vault_path: "characters/protagonist.md",
    source_digest: "a4f1c2…",
    projection_kind: "world_studio",
    projection_version: "v3",
    role_scope: "human",
    visibility_scope: "narrator",
    snapshots: [
      { version: 3, as_of_chapter: 12, digest: "a4f1c2" },
      { version: 2, as_of_chapter: 8, digest: "8b1d04" },
      { version: 1, as_of_chapter: 4, digest: "12a7c9" }
    ],
    frontmatter: {
      node_id: "char_001",
      page_key: "character:protagonist",
      page_type: "character",
      role_scope: "human",
      visibility_scope: "narrator",
      canon_status: "canon",
      source_refs: ["chapter:12#section-3", "genesis:characters-v3"],
      as_of_chapter: 12
    },
    markdown: `# 见习医师 · 沈柏舟

## Summary
灰烬城下风口的孤儿医师，自称只在医典里活着。十六岁就揭过一次叶蛰瘟，于是被议会塞进东市监工。

## Manual Notes
> 写作时记得：他遇到家人题材会跳成第三人称内心独白。

## Relationships
- antagonist_of → character:antagonist
- knows_of → artifact:codex
- lives_in → location:ash-city
`
  },
  {
    page_key: "character:antagonist",
    title: "议会议长 · 苏伯禹",
    page_type: "character",
    as_of_chapter: 12,
    revision: 6,
    status: "canon",
    vault_path: "characters/antagonist.md",
    source_digest: "e0a8b1…",
    projection_kind: "world_studio",
    projection_version: "v3",
    role_scope: "human",
    visibility_scope: "narrator",
    snapshots: [
      { version: 2, as_of_chapter: 12, digest: "e0a8b1" },
      { version: 1, as_of_chapter: 6, digest: "44d720" }
    ],
    frontmatter: { page_key: "character:antagonist", page_type: "character", as_of_chapter: 12 },
    markdown: "# 议会议长 · 苏伯禹\n\n## Summary\n灰烬城议会议长。出身世家，三十二岁掌典籍司。"
  },
  {
    page_key: "location:ash-city",
    title: "灰烬城",
    page_type: "location",
    as_of_chapter: 12,
    revision: 9,
    status: "canon",
    vault_path: "locations/ash-city.md",
    source_digest: "3b91fa…",
    projection_kind: "world_studio",
    projection_version: "v3",
    role_scope: "human",
    visibility_scope: "all",
    snapshots: [{ version: 3, as_of_chapter: 12, digest: "3b91fa" }],
    frontmatter: { page_key: "location:ash-city", page_type: "location" },
    markdown: "# 灰烬城\n\n## Summary\n建在死火山口的旧都，城墙是黑曜石。"
  },
  {
    page_key: "faction:council",
    title: "议会",
    page_type: "faction",
    as_of_chapter: 12,
    revision: 5,
    status: "canon",
    vault_path: "factions/council.md",
    source_digest: "7c2af3…",
    projection_kind: "world_studio",
    projection_version: "v3",
    role_scope: "human",
    visibility_scope: "narrator",
    snapshots: [{ version: 2, as_of_chapter: 12, digest: "7c2af3" }],
    frontmatter: { page_key: "faction:council", page_type: "faction" },
    markdown: "# 议会\n\n灰烬城最高决议体。"
  },
  {
    page_key: "artifact:codex",
    title: "蜡封药典",
    page_type: "artifact",
    as_of_chapter: 12,
    revision: 3,
    status: "canon",
    vault_path: "artifacts/codex.md",
    source_digest: "9aee10…",
    projection_kind: "world_studio",
    projection_version: "v3",
    role_scope: "human",
    visibility_scope: "limited",
    snapshots: [{ version: 1, as_of_chapter: 8, digest: "9aee10" }],
    frontmatter: { page_key: "artifact:codex", page_type: "artifact" },
    markdown: "# 蜡封药典\n\n以蜡封皮的孤本药典，只在每月初三对议员开放。"
  },
  {
    page_key: "event:plague",
    title: "黑霜瘟",
    page_type: "event",
    as_of_chapter: 12,
    revision: 4,
    status: "canon",
    vault_path: "events/black-frost.md",
    source_digest: "5ffc02…",
    projection_kind: "world_studio",
    projection_version: "v3",
    role_scope: "human",
    visibility_scope: "all",
    snapshots: [{ version: 2, as_of_chapter: 12, digest: "5ffc02" }],
    frontmatter: { page_key: "event:plague", page_type: "event" },
    markdown: "# 黑霜瘟\n\n每年冬至前后袭击灰烬城下风口村庄的瘟疫。"
  }
];

const PROJECT = {
  id: "PROJECT-2A8F",
  title: "灰烬城的最后见习医师",
  genre: "玄幻"
};

function App() {
  const [tab, setTab] = React.useState("pages");
  const [selectedPageKey, setSelectedPageKey] = React.useState("character:protagonist");
  const [primaryTab, setPrimaryTab] = React.useState("world");

  const selectedPage = SEED_PAGES.find((p) => p.page_key === selectedPageKey);

  return (
    <div className="world-studio-wrap" data-screen-label="World Studio">
      <nav className="nav-tabs">
        <a className="nav-tab" href="../creator-workspace/index.html">书本</a>
        <a className="nav-tab" href="../creator-workspace/index.html">任务</a>
        <button className="nav-tab active" type="button">世界档案</button>
        <a className="nav-tab" href="../creator-workspace/index.html">发布</a>
        <a className="nav-tab" href="../creator-workspace/index.html">配置</a>
      </nav>

      <WSMasthead project={PROJECT} />

      <div className="workspace" data-screen-label={`World Studio · ${tab}`}>
        <WSSidebar
          tab={tab}
          setTab={setTab}
          pages={SEED_PAGES}
          selectedPageKey={selectedPageKey}
          setSelectedPageKey={setSelectedPageKey}
        />
        <section className="main-panel">
          {tab === "pages" ? <WSPageDetail page={selectedPage} /> : null}
          {tab === "graph" ? <WSGraphView page={selectedPage} /> : null}
          {tab === "search" ? (
            <div className="empty" style={{ minHeight: 360, display: "grid", placeContent: "center" }}>
              <strong>World Studio Search</strong>
              <div>选择 canon、LLM KB、human notes 或 skill 索引后执行搜索。</div>
            </div>
          ) : null}
          {tab === "proposals" ? <WSProposals /> : null}
          {tab === "personality" ? <WSPersonality /> : null}
        </section>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
