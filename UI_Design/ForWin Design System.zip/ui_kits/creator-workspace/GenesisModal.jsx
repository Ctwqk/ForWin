/* global React, Badge, Button, Icon */

function GenesisStageChip({ stage, active, onClick }) {
  const cls = `stage-chip ${stage.locked ? "locked" : ""} ${active ? "active" : ""}`;
  return (
    <button type="button" className={cls} onClick={onClick}>
      <span style={{ font: "600 11px/1 var(--font-ui)", letterSpacing: "0.08em", textTransform: "uppercase", opacity: 0.7 }}>
        Stage {stage.idx}
      </span>
      · {stage.label}
      {stage.locked ? <Icon name="check" size={14} /> : null}
    </button>
  );
}

function GenesisModal({ open, book, onClose }) {
  const [stageIdx, setStageIdx] = React.useState(1);
  if (!open) return null;

  const stages = [
    { idx: 1, label: "世界观", locked: true },
    { idx: 2, label: "地图与空间", locked: true },
    { idx: 3, label: "角色与势力", locked: false },
    { idx: 4, label: "故事引擎", locked: false },
    { idx: 5, label: "Arc 蓝图", locked: false }
  ];
  const current = stages.find((s) => s.idx === stageIdx) ?? stages[0];

  return (
    <div className="modal-shell open" onClick={onClose}>
      <div className="modal large" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 14 }}>
          <div>
            <div className="task-id">{book?.id ?? "PROJECT-2A8F"} · Genesis Workspace</div>
            <h3>{book?.title ?? "Book Genesis Workspace"}</h3>
            <p className="muted" style={{ maxWidth: "58ch", margin: 0 }}>
              创建书本后，先在这里锁定世界观、地图、故事引擎和整本书 Arc 蓝图，再决定何时启动写作。
            </p>
          </div>
          <div className="action-row">
            <Button tone="primary" icon="play" disabled={!stages.every((s) => s.locked)}>
              启动写作
            </Button>
            <Button tone="ghost" onClick={onClose}>关闭</Button>
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {stages.map((s) => (
            <GenesisStageChip
              key={s.idx}
              stage={s}
              active={s.idx === stageIdx}
              onClick={() => setStageIdx(s.idx)}
            />
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.15fr) minmax(320px, 0.85fr)", gap: 18, alignItems: "start" }}>
          <section className="card">
            <div className="section-head" style={{ marginBottom: 0 }}>
              <div>
                <h3 style={{ fontSize: 22 }}>Stage {current.idx} · {current.label}</h3>
                <p className="muted" style={{ margin: 0 }}>
                  编辑或重生该阶段的根层数据。结构化字段同步回最终 JSON。
                </p>
              </div>
            </div>
            <div className="field-grid" style={{ marginTop: 12 }}>
              <div>
                <label className="field-label">主要冲突</label>
                <input className="field" defaultValue="见习医师 vs. 灰烬城议会" />
              </div>
              <div>
                <label className="field-label">命名规则</label>
                <input className="field" defaultValue="姓氏 · 单字名" />
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <label className="field-label">禁区 / Guardrails</label>
                <textarea className="field" rows={3} defaultValue={"不写大段血腥、不写穿越元素、不写现实政治影射。"} />
              </div>
            </div>
            <div style={{ marginTop: 14, display: "grid", gap: 10 }}>
              <label className="field-label">AI 对话改写</label>
              <textarea className="field" placeholder="像聊天一样告诉 AI 你想怎么改。可以改写整个阶段，也可以在选择子项后只改一个规则。" />
              <div className="action-row">
                <Button tone="secondary" icon="wand-sparkles">改写当前阶段</Button>
                <Button tone="ghost" icon="layers">改写选中子项</Button>
              </div>
            </div>
            <div className="action-row" style={{ marginTop: 14 }}>
              <Button tone="secondary" icon="save">保存编辑</Button>
              <Button tone="ghost" icon="rotate-cw">重生</Button>
              {current.locked ? <Badge tone="ok">当前阶段已锁定</Badge> : <Button tone="primary" icon="lock">锁定阶段</Button>}
            </div>
          </section>

          <section style={{ display: "grid", gap: 14 }}>
            <article className="card">
              <div className="task-id">阶段概览</div>
              <div className="muted" style={{ margin: "6px 0 10px" }}>
                {current.locked ? "本阶段已锁定。" : "未锁定。锁定后才会进入下一阶段。"}
              </div>
              <pre className="code">{`{
  "stage": "${current.label}",
  "locked": ${current.locked},
  "source_digest": "a4f1c2..."
}`}</pre>
            </article>
            <article className="card">
              <div className="task-id">Prompt Trace</div>
              <div style={{ display: "grid", gap: 10, marginTop: 8 }}>
                {[
                  { turn: 1, model: "MiniMax-M2.5", note: "Initial draft from premise" },
                  { turn: 2, model: "MiniMax-M2.5", note: "Refine map regions; merge 凤来山 → 凤栖山" }
                ].map((t) => (
                  <div key={t.turn} style={{ padding: 12, border: "1px solid rgba(204,177,147,.44)", borderRadius: 16, background: "rgba(255,255,255,.72)" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <strong style={{ font: "800 13px/1.2 var(--font-ui)" }}>Turn {t.turn}</strong>
                      <Badge>{t.model}</Badge>
                    </div>
                    <div className="muted" style={{ marginTop: 4 }}>{t.note}</div>
                  </div>
                ))}
              </div>
            </article>
          </section>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { GenesisModal });
