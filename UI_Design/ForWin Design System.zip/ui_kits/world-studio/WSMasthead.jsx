/* global React, Badge, Button, Icon, PrimaryNav */

function MetricCard({ icon, label, value, detail, tone = "neutral" }) {
  return (
    <div className={`metric ${tone === "neutral" ? "" : tone}`}>
      <div className="metric-icon"><Icon name={icon} size={18} /></div>
      <div>
        <div className="label">{label}</div>
        <div className="value">{value}</div>
        <div className="detail">{detail}</div>
      </div>
    </div>
  );
}

function WSMasthead({ project }) {
  return (
    <>
      <section className="masthead">
        <div>
          <div className="brand-mark">
            <img src="../../assets/brand-mark.svg" alt="" style={{ height: 22 }} />
            ForWin Archive
          </div>
          <h1 style={{ fontSize: 44, lineHeight: 1.04 }}>世界档案</h1>
          <p>
            Canon、Graph、Proposal、人物性格 loadout 都在一个工作台里。每次写作前回到这里同步一次世界模型。
          </p>
        </div>
        <div className="action-row">
          <label className="field-label" style={{ marginBottom: 0 }}>Project</label>
          <select className="field" style={{ width: 240 }} defaultValue={project.id}>
            <option value={project.id}>{project.title}</option>
            <option value="other-1">凤栖山志异</option>
          </select>
          <Button tone="secondary" icon="refresh-cw">刷新</Button>
        </div>
      </section>

      <div className="metric-grid">
        <MetricCard icon="database" label="Snapshot" value="第 12 章 · v3" detail="a4f1c2…" />
        <MetricCard icon="file-text" label="Pages" value="127" detail="6 types" />
        <MetricCard icon="shield-alert" label="Conflicts" value="2" detail="open" tone="warn" />
        <MetricCard icon="git-branch" label="Proposals" value="5" detail="pending" tone="warn" />
      </div>

      <div className="project-strip">
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <strong>{project.title}</strong>
          <span className="muted">{project.genre}</span>
        </div>
        <span className="muted">{project.id}</span>
      </div>

      <div className="toolbar">
        <form className="vault-form" onSubmit={(e) => e.preventDefault()}>
          <label className="field-label" style={{ marginBottom: 0 }}>Vault path</label>
          <input className="field" placeholder="默认 data/world_vaults/{project_id}" defaultValue="" />
          <Button tone="secondary" icon="download">导出</Button>
          <Button tone="ghost" icon="upload">导入 proposal</Button>
        </form>
      </div>
    </>
  );
}

Object.assign(window, { MetricCard, WSMasthead });
