# Creator Workspace — ForWin UI Kit

The Creator Workspace is ForWin's main page at `/`. The original lives in `forwin/ui_assets/home/{body.html, page.css, app_*.js}` — server-rendered HTML and a stack of plain JS bundles.

This kit re-implements the same surface as a small React composition so the design language is portable to a redesign.

## What's covered

- **Shell** — primary nav (书本 / 任务 / 世界档案 / 发布 / 配置), masthead with brand mark + headline, global status bar.
- **Books panel** — book list cards with cover thumbnail, chapter progress, platform bindings, action row.
- **Tasks panel** — unified task list mixing 生成 (generation) and 上传 (upload) tasks, with a right-side drawer.
- **Config panel** — Codex bridge state, model list, default generation settings, platform bindings.
- **Genesis modal** — staged blueprint workshop (世界观 → 地图 → 角色 → Arc → 启动写作) with prompt-trace and lock state.

## What's intentionally trimmed

- Real network calls / persistence — the kit uses local state with seeded data.
- Codex-bridge negotiation logic, freeze-failed candidates, all governance internals — these are backend concerns. The kit only shows the visual surfaces.
- The full edit flow inside the Genesis modal — we render two stages worth of fields and the prompt-trace.

Open `index.html` to see the kit running.
