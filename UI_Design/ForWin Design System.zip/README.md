# ForWin Design System

A design system distilled from the **ForWin** codebase — an AI-assisted Chinese long-form web-novel generation, governance, and publishing platform. Authors describe a premise, run a multi-stage *Genesis* workflow to lock world, map, characters and arc blueprints, then hand off to a runtime that drafts hundreds of chapters with governance checks, and finally pushes drafts to Chinese publishing platforms (Fanqie, etc.) through a browser extension.

The product surface has two distinct moods that this system unifies:

1. **Creator workspace** (`/`, `/publishers`) — the dominant brand voice. A warm, literary parchment aesthetic: cream paper, serif headlines, terracotta and deep-teal accents. Built around long writing sessions where the UI fades to a reading surface.
2. **World Studio** (`/world-studio`) — a structural data tool with denser pages, edges, conflicts, personality loadouts. The current implementation reaches for a generic neutral palette; this system folds it back into the parchment brand so the whole product feels like one workshop.

This design system is the **redesign baseline** — colors, type, motifs, components, and example screens that any new ForWin surface should compose from.

## Sources

The system was derived directly from the live ForWin codebase:

- GitHub: <https://github.com/Ctwqk/ForWin> (default branch: `master`)
- Key paths consulted:
  - `forwin/ui_assets/home/page.css` — the parchment design tokens and component patterns that anchor the brand
  - `forwin/ui_assets/home/body.html` — book, task, and Genesis workspace layouts
  - `forwin/api_pages_shared.py` — LLM provider presets (MiniMax, Kimi/Moonshot), favicon, asset wiring
  - `frontend/world-studio/src/styles.css`, `App.tsx` — the data-tool surface, its tabs, tables, graph view
  - `browser_extension/forwin-publisher/options.html` + `manifest.json` — the publisher bridge
  - `README.md` — product framing
- We also lean on **Lucide** icons (the codebase ships `lucide-react`), pulled from CDN in mock-ups.

Readers who want to push deeper on any surface should clone the repo and explore those files alongside this system.

## Product framing

ForWin is in essence a *novel factory*. The core nouns the UI repeats are:

- **书本** (Book) — a project with title, genre, target chapter count
- **任务** (Task) — a generation run or an upload run
- **世界档案** (World Archive / World Studio) — canon pages, the object graph, snapshots, proposals, character personality loadouts
- **发布** (Publish) — the platform bridge to external publishing sites
- **Genesis** — the multi-stage pre-writing workshop (world, map, characters, arc blueprint)
- **Proposal / Canon / Conflict** — the governance vocabulary that surrounds every edit

The system treats every screen as a *workshop*: paper-textured surface, hand-rendered serif headings, deliberate quietness, icon set kept light.

## Content fundamentals

ForWin's copy is **bilingual, technical-but-warm Mandarin**. The native voice is Chinese; English appears only as proper nouns or unambiguous technical terms (`Snapshot`, `Proposal`, `Operation Mode`, `Vault path`).

- **Audience**: a single power user who is both author and operator. Copy assumes they understand the term *canon*, *proposal*, *governance*, *band guard*, etc.
- **Voice**: declarative, second-person implicit, instruction-led. Sentences end with periods (`。`) and tend to be short paragraphs that explain *what this section does* rather than *what to do*.
- **Case**: English technical nouns retain source-case (`MiniMax`, `Kimi`, `Obsidian`, `WorldModel`, `BookState`). Chinese sentences mix freely with these terms.
- **Punctuation**: full-width Chinese punctuation (`，` `。` `、` `：`) for Chinese text; ASCII punctuation only inside code blocks and English-only sentences. The codebase uses ` · ` (middle dot, U+00B7) as a meta-list separator (`page.page_type · ch 12`).
- **Pronouns**: there is no "I" or "you" — copy is third-person about the system (`首页现在拆成…`, `任务中心继续承接…`). Imperatives are addressed to the system, not the user.
- **No emoji.** No exclamation marks. No marketing flourish.
- **Microcopy patterns**:
  - Section blurb: `<h2>Title</h2><p>这里…，…。</p>` — one or two short sentences explaining the slice and how it routes.
  - Button: 2–4 Chinese chars, primary verb-first (`刷新`, `新建任务`, `锁定阶段`, `生成 proposal`).
  - Status badge: `Label：value` (`API Key：已保存`, `扩展回写：未配置`).
  - Empty state: title + single sentence (`没有冲突` / `确定性 conflict detector 暂未发现 open issue。`).
  - Inline placeholder: full instructional sentences (`写清世界观、主角处境、关键冲突和你想要的开篇质感。`).

**Tone exemplars (verbatim from the codebase):**

> 配置归配置，任务归任务。

> 这里看每本书的章节规划、已生成章节和已上传章节。建书和后续生成从这里发起。

> 创建后会立即进入 Genesis 工作台，先敲定整本书的根蓝图，再决定何时启动写作。

> 锁定 Genesis 或导出 Obsidian 时会自动 bootstrap 第 0 章世界模型。

Note how each one names a concrete in-product noun, then ends with a calm instruction. Match this register when writing new copy.

## Visual foundations

**Surface.** The canvas is a parchment radial — never flat white. A soft warm gradient (`#f5ece0 → #eaddcc → #f4ecdf`) is dusted with a vertical 104px hand-ruled column pattern at 4% opacity. Panels sit on this surface as 22–28px-radius cards with a 1px warm hairline and a generous drop shadow. Cards lighten subtly toward the top (`linear-gradient(180deg, #fff∼.95, #faf4eb∼.92)`) to suggest paper sheen.

**Color.**
- **Primary:** terracotta `#b24b31` — only on primary CTAs, brand wordmarks, the "current" stage in a flow. Used as a 135° gradient to `#cb6a46` on filled buttons.
- **Secondary:** deep teal `#1f5b54` — secondary actions, eyebrows, ok-tone accents in metric cards.
- **Status:** `--ok` `#216841` (forest), `--warn` `#9b5a1d` (umber), `--danger` `#8b2e2e` (brick), `--info` `#2c5f7c` (slate-blue). All four are *muted* — they read as ink stamps, not signal lights. Each ships with a `_tint` companion at 8–13% alpha for background fills.
- **Ink:** body `#18211e`, secondary `#6d6255` (muted), hairline `rgba(204,177,147,.42)`.
- **Never** use pure black, pure white, or saturated blue/purple gradients.

**Type.** Serif display + UI sans, paired explicitly:
- Display / H1–H3: `Source Serif 4` (substituting for *Iowan Old Style*), tracked `-.04em`, weight 700–800.
- UI / labels / buttons: `Plus Jakarta Sans` (substituting for *Avenir Next*), weight 500–800.
- Chinese fallback: `Noto Serif SC` for display, `Noto Sans SC` for UI. Both load via Google Fonts.
- Mono: `JetBrains Mono` (substituting for *SFMono-Regular*) for code blocks, JSON editors, hashes.
- Body line-height runs 1.7 for UI prose, 1.85 for serif reading blocks; eyebrows ride `letter-spacing: 0.14em` uppercase.

**Spacing.** A 4-based scale (`4, 8, 12, 16, 20, 24, 32, 40, 56, 72`). Card interiors prefer 16–20px; section gutters 18–24px; modal padding 22px. Workspace columns at 1440 max width.

**Radii.** Workshop-soft: 6 (chips/tags), 12 (inputs), 18 (compact cards), 22 (cards), 28 (hero / modal). Buttons are pills (`999px`).

**Shadows.** Warm, low, never gray:
- Cards: `0 10px 28px rgba(56,36,17,.06)` with a 1px white inset highlight at the top edge.
- Hero surface: `0 20px 60px rgba(56,36,17,.12)`.
- Floating overlays / modals: `0 30px 80px rgba(34,24,14,.2)` over a `rgba(21,21,18,.28)` scrim with 4–5px backdrop blur.
- Buttons get a slight `translateY(-1px)` on hover, never a shadow change.

**Borders.** Default `1px solid rgba(204,177,147,.42)` (warm hairline). Status surfaces (`.ok`, `.warn`, `.failed`) swap to a 1px border in the status hue at ~24% alpha and a matching 8% tint fill. Dashed border only on empty states.

**Animation.** Restrained.
- Hover lift: `translateY(-1px)` over 160ms `ease-out`.
- Tab/panel cross-fade: 200ms.
- Modal/drawer: 320ms backdrop blur in, drawer slides 480ms from right with a soft spring.
- No bounce on UI, no infinite shimmers, no shimmery skeleton placeholders. When loading, show a calm `等待加载…` line in the existing card.

**Hover / press / focus.**
- Hover: 1px lift + slight `border-color` brighten (terracotta tint for primary, teal tint for secondary).
- Press: removes the lift; primary buttons darken to `--accent-deep`.
- Focus: 4px outer ring in `--accent-tint`; never a default browser blue.
- Disabled: `opacity: .48`, no transform, cursor `not-allowed`.

**Backgrounds.** Always the parchment paper. Never full-bleed photography. No illustrations (the brand doesn't ship any). Imagery, when needed, is *referenced* (book cover thumbnails inside cards) — never decoration.

**Transparency & blur.** Used only for modal backdrops and the right-side drawer overlay (~5px blur, ~30% scrim). Cards themselves are opaque-on-paper; we never stack glassmorphism on top of glassmorphism.

**Capsules vs gradients.** Brand CTAs are *gradients on solid pills* (`linear-gradient(135deg, accent, accent-bright)` on `border-radius: 999px`). Status surfaces use *tints on rounded rectangles* (`--ok-tint` fill, `--ok` border). Eyebrows use *outlined pills* in `--accent-tint-2`.

**Cards.** A ForWin card is recognizable from three layers:
1. Warm 1px hairline border (`--line-soft`)
2. Vertical paper gradient (`#fff∼.95 → #faf4eb∼.92`)
3. Soft warm shadow + 1px inset white highlight at the top

…inside, a `task-id`-style eyebrow caps the card, then an h2/h3 in serif, then prose in sans.

**Layout rules.**
- Top-level shell width: `min(1380px, calc(100vw - 32px))`, centered.
- Primary nav: horizontal pill rail at the very top, never a sidebar at top-level.
- Two-column tools (World Studio, Genesis): 360–420px left column ("library / index"), fluid right column ("workspace"). Single-column collapse at 1080px.
- Modals: centered, max 1320px for Genesis, 840px otherwise.
- Drawers: right-aligned, `min(960px, 100vw)`.

## Iconography

ForWin standardizes on **[Lucide](https://lucide.dev/)** — the codebase imports `lucide-react` (`^0.468.0`). Icons are line-only, 1.5–2px stroke, 16–22px in UI, rendered in `--ink` (body) or `--accent-2` (eyebrow-bound). Icons we observed in source:

- Navigation / objects: `BookOpen`, `GitBranch`, `Database`, `FileText`, `UserRound`
- Actions: `RefreshCw`, `Download`, `Upload`, `Search`, `Check`, `X`
- Status: `ShieldAlert` (warnings/conflicts)

We **do not** use emoji anywhere. Unicode mid-dot (` · `) is used as a meta-list separator. The favicon (see `assets/favicon.svg`) is a warm-ink rounded square with the "FW" wordmark in cream serif. There are no other shipped logos or illustrations in the codebase; the brand surface itself *is* the parchment.

For prototypes in this design system we load Lucide from CDN (`https://unpkg.com/lucide@latest`) rather than re-drawing SVGs. If a glyph genuinely doesn't exist in Lucide, fall back to a CJK character at body weight (e.g. `世` inside a circle for World Archive) — never a hand-drawn SVG.

## Visual foundations summary (cheat-sheet)

| Token group | Where it lives | When to reach for it |
|---|---|---|
| Parchment surface (`--paper*`) | Page `body` background | Default canvas. Never override. |
| `--panel`, `--panel-2` | Card body | Any content container |
| `--accent` terracotta | Primary CTA, brand mark, current/active stage | Once per view |
| `--accent-2` teal | Secondary CTA, eyebrows, ok metrics | Often, restrained |
| `--ok / --warn / --danger / --info` | Badges, status borders, severity pills | Always with the `_tint` partner |
| Serif H1–H3 | Page title, modal title, drawer title | Never on buttons |
| UI sans 500–800 | Buttons, labels, meta, badges, eyebrows | Default UI |
| Pill buttons | Every action | Never square buttons |
| 22–28px radius cards | Every panel | Smaller radii only for chips & inputs |

---

## Index of this design system

```
README.md                       — you are here
SKILL.md                        — Claude Code skill descriptor
colors_and_type.css             — Foundation tokens, type scale, motion, elevation

assets/
  favicon.svg                   — ForWin "FW" mark, parchment palette
  brand-mark.svg                — Stamped-ink rounded badge with FW lockup
  paper-texture.svg             — Reusable paper-grain SVG pattern

fonts/                          — (Google Fonts substitutes — see substitutions note below)

preview/                        — Cards rendered in the Design System tab
  type-display.html             — Display + headings
  type-body.html                — Body, prose, meta, mono
  type-eyebrow.html             — Eyebrows + labels + captions
  colors-brand.html             — Terracotta + teal swatches
  colors-neutrals.html          — Paper, panel, ink, hairline
  colors-status.html            — ok / warn / danger / info
  spacing-scale.html            — 4-step scale visual
  radii-shadow.html             — Radii + shadow elevation
  motion-easing.html            — Easings + durations
  buttons.html                  — Primary / secondary / ghost / danger
  inputs.html                   — Input, textarea, select, checkbox
  badges-pills.html             — Status badges, tab pills, eyebrow chips
  cards.html                    — Surface, card-with-eyebrow, list-item
  navigation.html               — Primary nav tabs, pill-switch
  metrics.html                  — Metric grid, status-bar
  empty-state.html              — Calm empty + dashed border treatment

ui_kits/
  creator-workspace/
    README.md                   — Creator workspace kit notes
    index.html                  — Books + Tasks + Genesis hi-fi mock
    *.jsx                       — Components

  world-studio/
    README.md                   — World Studio kit notes
    index.html                  — World Studio rebrought into parchment palette
    *.jsx                       — Components
```

## Substitution notes for the user

You see the substitutions marked `(substituting for …)` above — the codebase points at `Avenir Next`, `Iowan Old Style`, `SFMono-Regular`, and `Source Han Serif SC` / `PingFang SC` which are not freely redistributable. We've matched them with Google Fonts equivalents that load reliably and have full CJK support:

| Original | Substitute | Notes |
|---|---|---|
| Iowan Old Style | **Source Serif 4** | Same transitional-serif feel; sturdier on screen |
| Avenir Next | **Plus Jakarta Sans** | Slightly more contemporary; matches geometric proportions |
| Source Han Serif SC / Songti | **Noto Serif SC** | Same Source Han family, open weight |
| PingFang SC | **Noto Sans SC** | Same superset |
| SFMono-Regular | **JetBrains Mono** | Open-source, ligature-aware mono |

**Please flag if you'd prefer the licensed originals** — drop the `.ttf`/`.woff2` files into `fonts/` and I'll rewrite the `@import` rules to point at them.
