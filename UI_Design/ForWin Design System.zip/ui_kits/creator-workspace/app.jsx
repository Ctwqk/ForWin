/* global React, ReactDOM, PrimaryNav, StatusBar, Masthead, BookPanel, TaskPanel, ConfigPanel, GenesisModal, Button, Badge */

const SEED_BOOKS = [
  {
    id: "PROJECT-2A8F",
    title: "灰烬城的最后见习医师",
    glyph: "灰烬城",
    genre: "玄幻",
    chaptersTotal: 60,
    chaptersDone: 12,
    chaptersUploaded: 8,
    audience: "男频",
    status: "Genesis 已锁定",
    badges: [
      { tone: "ok", label: "canon locked" },
      { tone: "neutral", label: "checkpoint" },
      { tone: "neutral", label: "Fanqie + Zongheng" }
    ]
  },
  {
    id: "PROJECT-71BC",
    title: "凤栖山志异",
    glyph: "凤栖山",
    genre: "古言悬疑",
    chaptersTotal: 40,
    chaptersDone: 4,
    chaptersUploaded: 0,
    audience: "女频",
    status: "Genesis 进行中",
    badges: [
      { tone: "warn", label: "Genesis stage 3" },
      { tone: "neutral", label: "MiniMax" }
    ]
  },
  {
    id: "PROJECT-93D2",
    title: "缝补海岸的钟匠",
    glyph: "缝补海岸",
    genre: "硬核奇幻",
    chaptersTotal: 90,
    chaptersDone: 0,
    chaptersUploaded: 0,
    audience: "泛读者",
    status: "草稿",
    badges: [
      { tone: "neutral", label: "draft" }
    ]
  }
];

const SEED_TASKS = [
  {
    id: "TASK-GEN-118",
    kind: "generation",
    title: "灰烬城 · 第 13–15 章生成",
    summary: "blackbox · MiniMax-M2.5 · 每章最低 2800 字",
    statusLabel: "运行中",
    toneOverall: "info",
    modelProfile: "MiniMax 主账号",
    updatedAt: "更新于 2 分钟前",
    stages: [
      { state: "completed", label: "Plan", note: "目录已锁" },
      { state: "completed", label: "Draft 13", note: "3160 字" },
      { state: "current", label: "Draft 14", note: "运行中 · 1860/2800" },
      { state: "upcoming", label: "Draft 15", note: "排队" },
      { state: "upcoming", label: "Review", note: "" },
      { state: "upcoming", label: "Commit", note: "" }
    ]
  },
  {
    id: "TASK-UP-204",
    kind: "upload",
    title: "凤栖山志异 · 推送第 4 章",
    summary: "Fanqie · publish=true · create_if_missing=true",
    statusLabel: "等待扩展",
    toneOverall: "warn",
    modelProfile: "凤栖山志异",
    updatedAt: "更新于 9 分钟前",
    stages: []
  },
  {
    id: "TASK-GEN-117",
    kind: "generation",
    title: "灰烬城 · 第 12 章修订",
    summary: "copilot · Kimi K2 Thinking",
    statusLabel: "已完成",
    toneOverall: "ok",
    modelProfile: "Kimi 主账号",
    updatedAt: "完成于 35 分钟前",
    stages: [
      { state: "completed", label: "Plan", note: "" },
      { state: "completed", label: "Draft", note: "2980 字" },
      { state: "completed", label: "Review", note: "no flags" },
      { state: "completed", label: "Commit", note: "rev 14" }
    ]
  }
];

const SEED_PROFILES = [
  { id: "p1", name: "MiniMax 主账号", provider: "MiniMax", model: "MiniMax-M2.5", baseUrl: "https://api.minimax.chat/v1", isDefault: true },
  { id: "p2", name: "Kimi 主账号", provider: "Moonshot", model: "kimi-k2-thinking", baseUrl: "https://api.moonshot.cn/v1" }
];

const SEED_PLATFORMS = [
  { id: "fanqie", name: "番茄小说 (Fanqie)", loggedIn: true, extensionOnline: true, client: "FW-EXT-A1" },
  { id: "zongheng", name: "纵横中文网", loggedIn: true, extensionOnline: true, client: "FW-EXT-A1" },
  { id: "qidian", name: "起点中文网", loggedIn: false, extensionOnline: false, client: "—" }
];

function App() {
  const [tab, setTab] = React.useState("book");
  const [genesisBook, setGenesisBook] = React.useState(null);

  return (
    <div className="wrap" data-screen-label="Creator Workspace">
      <PrimaryNav tab={tab} setTab={setTab} />
      <Masthead />

      <section className="surface" data-screen-label={`Workspace · ${tab}`}>
        <StatusBar tasksRunning={3} apiKeyOk={true} codexBridgeOk={true} extensionOk={true} />

        <div className="tabs">
          <button className={`tab-chip ${tab === "book" ? "active" : ""}`} onClick={() => setTab("book")}>书本</button>
          <button className={`tab-chip ${tab === "task" ? "active" : ""}`} onClick={() => setTab("task")}>任务</button>
          <button className={`tab-chip ${tab === "config" ? "active" : ""}`} onClick={() => setTab("config")}>配置</button>
        </div>

        <div className="tab-panel">
          {tab === "book" ? (
            <BookPanel
              books={SEED_BOOKS}
              onNewBook={() => setGenesisBook({ id: "NEW", title: "新书 · Untitled" })}
              onOpenGenesis={(book) => setGenesisBook(book)}
            />
          ) : null}
          {tab === "task" ? (
            <TaskPanel
              tasks={SEED_TASKS}
              onOpen={() => {}}
              onNewTask={() => {}}
            />
          ) : null}
          {tab === "config" ? (
            <ConfigPanel profiles={SEED_PROFILES} platforms={SEED_PLATFORMS} />
          ) : null}
        </div>
      </section>

      <GenesisModal open={!!genesisBook} book={genesisBook} onClose={() => setGenesisBook(null)} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
