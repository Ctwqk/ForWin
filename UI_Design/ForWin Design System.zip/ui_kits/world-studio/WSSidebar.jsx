/* global React, Icon, Badge, Button */

const SIDEBAR_TABS = [
  { key: "pages", label: "页面", icon: "book-open" },
  { key: "graph", label: "图谱", icon: "git-branch" },
  { key: "search", label: "搜索", icon: "search" },
  { key: "proposals", label: "Proposal", icon: "file-text" },
  { key: "personality", label: "人物性格", icon: "user-round" }
];

function WSSidebar({ tab, setTab, pages, selectedPageKey, setSelectedPageKey }) {
  const [query, setQuery] = React.useState("");
  const filtered = pages.filter((p) => !query || (p.title + p.page_key).toLowerCase().includes(query.toLowerCase()));

  return (
    <aside className="sidebar">
      <div className="sidebar-tabs" role="tablist">
        {SIDEBAR_TABS.map((t) => (
          <button
            key={t.key}
            className={tab === t.key ? "active" : ""}
            onClick={() => setTab(t.key)}
            type="button"
          >
            <Icon name={t.icon} size={14} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "pages" ? (
        <>
          <div className="search-row">
            <Icon name="search" size={16} color="var(--muted)" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="搜索页面" />
          </div>
          <select className="field">
            <option>全部类型</option>
            <option>character</option>
            <option>location</option>
            <option>faction</option>
            <option>artifact</option>
            <option>event</option>
          </select>
          <div className="page-list">
            {filtered.map((p) => (
              <button
                key={p.page_key}
                className={`page-item ${p.page_key === selectedPageKey ? "active" : ""}`}
                onClick={() => setSelectedPageKey(p.page_key)}
                type="button"
              >
                <strong>{p.title}</strong>
                <small>{p.page_type} · ch {p.as_of_chapter} · rev {p.revision}</small>
              </button>
            ))}
          </div>
        </>
      ) : null}

      {tab === "graph" ? (
        <>
          <div className="field-stack">
            <label>Depth</label>
            <select className="field"><option>1-hop</option><option>2-hop</option></select>
          </div>
          <div className="field-stack">
            <label>Node Type</label>
            <select className="field"><option>全部类型</option><option>character</option><option>location</option></select>
          </div>
          <div className="field-stack">
            <label>Edge Family</label>
            <select className="field">
              <option>全部关系</option>
              <option>social</option>
              <option>control_conflict</option>
              <option>knowledge_visibility</option>
              <option>reader_experience</option>
            </select>
          </div>
          <div className="field-stack">
            <label>Status</label>
            <select className="field"><option>active</option><option>resolved</option><option>suspected</option></select>
          </div>
        </>
      ) : null}

      {tab === "search" ? (
        <>
          <div className="search-row">
            <Icon name="search" size={16} color="var(--muted)" />
            <input placeholder="搜索 canon / notes / LLM KB / skill" />
          </div>
          <select className="field">
            <option>all</option>
            <option>canon</option>
            <option>llm_kb</option>
            <option>obsidian_human</option>
            <option>skill</option>
          </select>
          <Button tone="primary" icon="search">搜索</Button>
        </>
      ) : null}

      {tab === "proposals" ? (
        <div className="page-list">
          {[
            { id: "PR-21", target: "character:protagonist", source: "world_studio", note: "Manual notes" },
            { id: "PR-22", target: "location:ash-city", source: "obsidian_import", note: "Frontmatter mismatch" },
            { id: "PR-23", target: "character:antagonist", source: "world_studio", note: "Proposed correction" }
          ].map((pr) => (
            <button key={pr.id} className="page-item" type="button">
              <strong>{pr.target}</strong>
              <small>{pr.id} · {pr.source} · {pr.note}</small>
            </button>
          ))}
        </div>
      ) : null}

      {tab === "personality" ? (
        <div className="coverage-panel">
          <div className="header">
            <strong style={{ font: "800 22px/1 var(--font-display)" }}>78%</strong>
            <Badge tone="ok">14 / 18 valid</Badge>
          </div>
          <div className="muted" style={{ fontSize: 12 }}>Coverage of personality loadouts across project characters.</div>
          <div className="stats">
            <span className="stat-pill">missing 2</span>
            <span className="stat-pill">fallback 1</span>
            <span className="stat-pill">manual 3</span>
            <span className="stat-pill">needs review 1</span>
          </div>
        </div>
      ) : null}
    </aside>
  );
}

Object.assign(window, { WSSidebar });
